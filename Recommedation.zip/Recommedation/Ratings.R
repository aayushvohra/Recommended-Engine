library(data.table)
library(readxl)
library(recommenderlab)
library(reshape2)
ratings_list <- read_xlsx("G:/practical data science/Assignments/Recommedation/Ratings.xlsx")
head(ratings_list)
ratings_list <- ratings_list[,2:4]
head(ratings_list)
dim(ratings_list)
##convert to matrix format
?acast
ratings_matrix <- as.matrix(acast(ratings_list, user_id~joke_id, fun.aggregate = mean))
dim(ratings_matrix)
## recommendarlab realRatingMatrix format
R <- as(ratings_matrix, "realRatingMatrix")
rec1 = Recommender(R, method="UBCF") ## User-based collaborative filtering
rec2 = Recommender(R, method="IBCF") ## Item-based collaborative filtering
rec3 = Recommender(R, method="SVD")
rec4 = Recommender(R, method="POPULAR")
rec5 = Recommender(binarize(R,minRating=2), method="UBCF") ## binarize all 2+ rating to 1
## create n recommendations for a user
uid = "31030"
joke <- subset(ratings_list, ratings_list$joke_id==uid)
print("You have rated:")
joke
print("recommendations for you:")
prediction <- predict(rec1, R[uid], n=2)## you may change the model here
as(prediction, "list")
prediction <- predict(rec2, R[uid], n=2) ## you may change the model here
as(prediction, "list")
prediction <- predict(rec3, R[uid], n=2) ## you may change the model here
as(prediction, "list")
prediction <- predict(rec4, R[uid], n=2) ## you may change the model here
as(prediction, "list")
prediction <- predict(rec5, R[uid], n=2) ## you may change the model here
as(prediction, "list")