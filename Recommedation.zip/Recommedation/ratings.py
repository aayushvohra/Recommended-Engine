# -*- coding: utf-8 -*-
"""
Created on Wed Oct 28 22:38:26 2020

@author: AAYUSH VOHRA
"""
import pandas as pd
#import Dataset 
anime = pd.read_csv("G:/practical data science/Assignments/Recommedation/Ratings.csv")
anime.shape #shape
anime.columns
anime.genre #genre columns
from sklearn.feature_extraction.text import TfidfVectorizer
tfidf = TfidfVectorizer(stop_words="english")
anime["genre"].isnull().sum() 
anime["genre"] = anime["genre"].fillna(" ")
tfidf_matrix = tfidf.fit_transform(anime.genre)   #Transform a count matrix to a normalized tf or tf-idf representation
tfidf_matrix.shape 

from sklearn.metrics.pairwise import linear_kernel

# Computing the cosine similarity on Tfidf matrix
cosine_sim_matrix = linear_kernel(tfidf_matrix,tfidf_matrix)
# creating a mapping of anime name to index number 
anime_index = pd.Series(anime.index,index=anime['name']).drop_duplicates()
anime_index["Hunter x Hunter (2011)"]

def get_anime_recommendations(Name,topN):
    
   
    #topN = 10
    # Getting the movie index using its title 
    anime_id = anime_index[Name]
    
    # Getting the pair wise similarity score for all the anime's with that 
    # anime
    cosine_scores = list(enumerate(cosine_sim_matrix[anime_id]))
    
    # Sorting the cosine_similarity scores based on scores 
    cosine_scores = sorted(cosine_scores,key=lambda x:x[1],reverse = True)
    
    # Get the scores of top 10 most similar anime's 
    cosine_scores_10 = cosine_scores[0:topN+1]
    
    # Getting the anime index 
    anime_idx  =  [i[0] for i in cosine_scores_10]
    anime_scores =  [i[1] for i in cosine_scores_10]
    
    # Similar movies and scores
    anime_similar_show = pd.DataFrame(columns=["name","Score"])
    anime_similar_show["name"] = anime.loc[anime_idx,"name"]
    anime_similar_show["Score"] = anime_scores
    anime_similar_show.reset_index(inplace=True)  
    anime_similar_show.drop(["index"],axis=1,inplace=True)
    print (anime_similar_show)
    #return (anime_similar_show)
# Enter your anime and number of anime's to be recommended 
get_anime_recommendations("Ginga Eiyuu Densetsu",topN=5)

